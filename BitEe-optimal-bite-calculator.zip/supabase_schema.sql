﻿-- =========================================================================
-- BitEe: Optimal Bite Calculator - Supabase Database Schema (Idempotent)
-- =========================================================================

-- 1. Create the sandwiches table
create table if not exists public.sandwiches (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  creator_name text default 'Anonymous Sandwich Engineer',
  efficiency numeric not null,
  bite_angle numeric not null,
  total_thickness numeric not null,
  flavor_lift numeric not null,
  layers jsonb not null,
  upvotes integer default 0,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 2. Create index for fast sorting & querying
create index if not exists idx_sandwiches_created_at on public.sandwiches (created_at desc);
create index if not exists idx_sandwiches_efficiency on public.sandwiches (efficiency desc);

-- 3. Enable Row Level Security (RLS)
alter table public.sandwiches enable row level security;

-- 4. Re-create Policies safely (Drop first if existing)
drop policy if exists "Allow public read" on public.sandwiches;
drop policy if exists "Allow public insert" on public.sandwiches;
drop policy if exists "Allow public upvote" on public.sandwiches;
drop policy if exists "Allow public read access" on public.sandwiches;
drop policy if exists "Allow public upvote updates" on public.sandwiches;

create policy "Allow public read"
  on public.sandwiches
  for select
  using (true);

create policy "Allow public insert"
  on public.sandwiches
  for insert
  with check (true);

create policy "Allow public upvote"
  on public.sandwiches
  for update
  using (true)
  with check (true);
